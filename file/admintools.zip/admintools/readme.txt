copyright (c) JBB 2015
License WTFPL

you can do what a fuck you want :)
