
-- registering of the main blocks
minetest.register_node("roof:clay", {
	description = "Clay roof block",
	tiles = {"roof_clay.png"},
	groups = {cracky=2, roof=1, not_in_creative_inventory=1 },
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("roof:tree", {
	description = "tree roof block",
	tiles = {"default:tree.png"},
	groups = {cracky=2, roof=1, not_in_creative_inventory=1 },
	sounds = default.node_sound_stone_defaults(),
})

--adding the stairs
stairs.register_stair_and_slab("roof_clay", "roof:clay",
		{cracky=2},
		{"roof_clay.png"},
		"Clay roof",
		"Clay roof Slab",
		default.node_sound_stone_defaults())
		
stairs.register_stair_and_slab("roof_straw", "farming:straw",
		{cracky=3},
		{"farming_straw.png"},
		"Straw roof",
		"Straw roof Slab",
		default.node_sound_stone_defaults())
	
stairs.register_stair_and_slab("roof_tree", "roof:tree",
		{cracky=3},
		{"default_tree.png"},
		"Tree roof",
		"Tree roof Slab",
		default.node_sound_stone_defaults())
		
--craftings
minetest.register_craft({
	output = 'stairs:stair_roof_clay 2',
	recipe = {
		{'', '', 'default:clay'},
		{'', 'default:clay', 'default:clay'},
		{'default:clay', 'default:clay', 'default:clay'},
	}
})

minetest.register_craft({
	output = 'stairs:stair_roof_straw 2',
	recipe = {
		{'', '', 'farming:straw'},
		{'', 'farming:straw', 'farming:straw'},
		{'farming:straw', 'farming:straw', 'farming:straw'},
	}
})

minetest.register_craft({
	output = 'stairs:stair_roof_tree 2',
	recipe = {
		{'', '', 'default:tree'},
		{'', 'default:tree', 'default:tree'},
		{'default:tree', 'default:tree', 'default:tree'},
	}
})

minetest.register_craft({
	output = 'stairs:slab_roof_clay 2',
	recipe = {
		{'default:clay', 'default:clay', 'default:clay'},
	}
})

minetest.register_craft({
	output = 'stairs:slab_roof_straw 2',
	recipe = {
		{'farming:straw', 'farming:straw', 'farming:straw'},
	}
})

minetest.register_craft({
	output = 'stairs:slab_roof_tree 2',
	recipe = {
		{'default:tree', 'default:tree', 'default:tree'},
	}
})


--short Aliases for /give


minetest.register_alias("roof_clay", "stairs:stair_roof_clay")
minetest.register_alias("roof_straw", "stairs:stair_roof_straw")
minetest.register_alias("roof_clay_slab", "stairs:slab_roof_clay")
minetest.register_alias("roof_straw_slab", "stairs:slab_roof_straw")
minetest.register_alias("roof_tree", "stairs:stair_roof_tree")
minetest.register_alias("roof_tree_slab", "stairs:slab_roof_tree")
