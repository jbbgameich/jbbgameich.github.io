dofile(minetest.get_modpath("agriculture") .. "/carrot.lua")
dofile(minetest.get_modpath("agriculture") .. "/sugar_beet.lua")
dofile(minetest.get_modpath("agriculture") .. "/strawberry.lua")
dofile(minetest.get_modpath("agriculture") .. "/corn.lua")
dofile(minetest.get_modpath("agriculture") .. "/tomato.lua")
dofile(minetest.get_modpath("agriculture") .. "/changes.lua")



-- getting salt

minetest.register_craft( {
	type = "cooking",
        cooktime = 5,
        output = "agriculture:salt 6",
        recipe = "bucket:bucket_water",
	replacements = { {"bucket:bucket_water", "bucket:bucket_empty"}, },
})



minetest.register_craftitem("agriculture:salt", {
	description = "Salt",
	inventory_image = "agriculture_salt.png",
})

