

-- getting the seeds



for i = 1, 5 do		
	minetest.override_item("default:grass_"..i, {drop = {
		max_items = 1,
		items = {
			{items = {'farming:seed_wheat'},rarity = 5},
			{items = {'default:grass_1'}},
		}
	}})
end

for i = 1, 5 do		
	minetest.override_item("default:dry_grass_"..i, {drop = {
		max_items = 1,
		items = {
                        {items = {'agriculture:seed_sugar_beet'},rarity = 5},
			{items = {'default:dry_grass_1'}},
		}
	}})
end

    minetest.override_item("default:junglegrass", {drop = {
            max_items = 1,
            items = {
                    {items = {'agriculture:seed_carrot'},rarity = 5},
                    {items = {'default:junglegrass'}},
            }
    }})


    minetest.override_item("default:papyrus", {drop = {
            max_items = 1,
            items = {
                    {items = {'agriculture:seed_corn'},rarity = 5},
                    {items = {'default:papyrus'}},
            }
    }})

    
      minetest.override_item("default:dirt_with_grass", {drop = {
            max_items = 1,
            items = {
                    {items = {'agriculture:tomato_seed'},rarity = 8 ,'default:dirt' },
                    {items = {'agriculture:seed_sugar_beet'},rarity = 12 ,'default:dirt' },
                    {items = {'default:dirt'}},
            }
    }})

      minetest.override_item("default:dry_shrub", {drop = {
            max_items = 1,
            items = {
                    {items = {'agriculture:seed_strawberry'},rarity = 8},
                    {items = {'default:dry_shrub'}},
            }
    }})
    
    -- farming mod changes
   

minetest.register_craftitem("agriculture:straw_bundle", {
	description = "Straw Bundle",
	inventory_image = "agriculture_straw_bundle.png",
})

    
minetest.override_item("farming:wheat_8", {
     drop = "farming:wheat 3"   
})

minetest.register_craft({
	type = "shapeless",
	output = "farming:seed_wheat",
	recipe = {"farming:wheat"},
	replacements = { {"farming:wheat", "agriculture:straw_bundle"}, }
})


minetest.register_craft({
	output = "farming:straw 3",
	recipe = {
		{"agriculture:straw_bundle", "agriculture:straw_bundle", "agriculture:straw_bundle"},
		{"agriculture:straw_bundle", "agriculture:straw_bundle", "agriculture:straw_bundle"},
		{"agriculture:straw_bundle", "agriculture:straw_bundle", "agriculture:straw_bundle"},
	}
})


minetest.register_craft({
	type = "shapeless",
	output = "farming:flour",
	recipe = {"farming:seed_wheat", "farming:seed_wheat", "farming:seed_wheat", "farming:seed_wheat"}
})



minetest.override_item("farming:cotton_8", {
     drop = "farming:cotton 2"   
})

minetest.register_craft({
	type = "shapeless",
	output = "farming:seed_cotton 2",
	recipe = {"farming:cotton"}
})
